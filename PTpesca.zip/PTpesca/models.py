from django.db import models

class Fabricante(models.Model):   
    nome = models.CharField(max_length=20, null=False, blank=False)
    datanasc = models.CharField(max_length=200, null=True, blank=True)
    datafal = models.CharField(max_length=200, null=True, blank=True)
    nacionalidade = models.CharField(max_length=200, null=True, blank=True)
    def __str__(self):
        return self.nome
    def isAlive(self):
        return datafal==False

class Canadepesca(models.Model):
    fabricante = models.ForeignKey(Fabricante, on_delete=models.CASCADE)
    material = models.CharField(max_length=200, null=True, blank=True)
    modelo = models.CharField(max_length=200, null=True, blank=True)
    peso = models.IntegerField(null=True, blank=True)
    tamanho = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.fabricante.nome+"-"+self.modelo

class Imagem(models.Model):
    link = models.URLField(max_length=500, null=False, blank=False)
    canadepesca = models.ForeignKey(Canadepesca, on_delete=models.CASCADE)
    def __str__(self):
        return self.link

class Pescador(models.Model):
    nome = models.CharField(max_length=20, null=False, blank=False)
    datanasc = models.CharField(max_length=200, null=True, blank=True)
    datafal = models.CharField(max_length=200, null=True, blank=True)
    nacionalidade = models.CharField(max_length=200, null=True, blank=True)
    def __str__(self):
        return self.nome
    def isAlive(self):
        return datafal==False

class Pesca(models.Model):
    zona = models.CharField(max_length=200, null=True, blank=True)
    tipo = models.CharField(max_length=200, null=True, blank=True)
    pescador = models.ForeignKey(Pescador, on_delete=models.CASCADE)
    canadepesca = models.ForeignKey(Canadepesca, on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return self.zona
