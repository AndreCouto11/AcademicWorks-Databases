from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from .models import Fabricante
from .models import Canadepesca
from .models import Pescador
from .models import Imagem
from .models import Pesca

def index(request):
    template = loader.get_template('PTpesca/index.html')
    context = {
        'numFabricantes':Fabricante.objects.all().count(),
        'numCanasdepesca':Canadepesca.objects.all().count(),
        'numPescadores':Pescador.objects.all().count(),
        'numPescas':Pesca.objects.all().count(),
        'numImagens':Imagem.objects.all().count(),
    }
    return HttpResponse(template.render(context, request))

def Fabricantes(request):
    template = loader.get_template('PTpesca/fabricantes.html')
    items = Fabricante.objects.order_by('nome')[0:]
    context = {
        'fabricantes':items
    }
    return HttpResponse(template.render(context, request))

def FabricanteDetalhes(request, fabricante_id):
    template = loader.get_template('PTpesca/fabricanteDetalhes.html')
    try:
        myFabricante = Fabricante.objects.get(pk=fabricante_id)
        myFabricanteCanasdepesca = Canadepesca.objects.filter(fabricante = fabricante_id)
        context = {'fabricante' : myFabricante, 'canasdepesca' : myFabricanteCanasdepesca}
    except Fabricante.DoesNotExist:
        raise Http404("Nao existe fabricante")

    return HttpResponse(template.render(context, request))


def Pescadores(request):
    template = loader.get_template('PTpesca/pescadores.html')
    items = Pescador.objects.order_by('nome')[0:]
    context = {
        'pescadores':items
    }
    return HttpResponse(template.render(context, request))

def PescadorDetalhes(request, pescador_id):
    template = loader.get_template('PTpesca/pescadorDetalhes.html')
    try:
        myPescador = Pescador.objects.get(pk=pescador_id)
        myPescas = Pesca.objects.filter(pescador = pescador_id)
        context = {'pescador' : myPescador, 'pescas' : myPescas}
    except Pescador.DoesNotExist:
        raise Http404("Nao existe pescador")

    return HttpResponse(template.render(context, request))

def Canasdepesca(request):
    template = loader.get_template('PTpesca/canasdepesca.html')
    items = Canadepesca.objects.order_by('fabricante', 'modelo')[0:]
    context = {
        'canasdepesca':items
    }
    return HttpResponse(template.render(context, request))

def Imagens(request):
    template = loader.get_template('PTpesca/imagens.html')
    items = Imagem.objects.order_by('canadepesca', 'link')[0:]
    context = {
        'imagens':items
    }
    return HttpResponse(template.render(context, request))

def CanadepescaDetalhes(request, canadepesca_id):
    template = loader.get_template('PTpesca/canadepescaDetalhes.html')
    try:
        canadepesca = Canadepesca.objects.get(pk = canadepesca_id)
        myImagens = Imagem.objects.filter(canadepesca = canadepesca_id)
        context = {'canadepesca' : canadepesca, 'imagens' : myImagens}
    except Canadepesca.DoesNotExist:
        raise Http404("Nao existem Canas de pesca")
    return HttpResponse(template.render(context, request))

def Pescas(request):
    template = loader.get_template('PTpesca/pescas.html')
    items = Pesca.objects.order_by('pescador', 'id')[0:]
    context = {
        'pescas':items
    }
    return HttpResponse(template.render(context, request))

def PescaDetalhes(request, pesca_id):
    template = loader.get_template('PTpesca/pescaDetalhes.html')
    try:
        pesca = Pesca.objects.get(id = pesca_id)
        context = {'pesca' : pesca}
    except Pesca.DoesNotExist:
        raise Http404("Nao existe pesca")
    return HttpResponse(template.render(context, request))
