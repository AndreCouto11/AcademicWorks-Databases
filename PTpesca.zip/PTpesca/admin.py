from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

# Register your models here.
from .models import Fabricante
from .models import Canadepesca
from .models import Pescador
from .models import Imagem
from .models import Pesca

admin.site.register(Fabricante)
admin.site.register(Canadepesca)
admin.site.register(Pescador)
admin.site.register(Imagem)
admin.site.register(Pesca)
