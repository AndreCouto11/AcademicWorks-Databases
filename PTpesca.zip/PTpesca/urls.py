from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

    #fabricantes
    path('fabricantes', views.Fabricantes, name='fabricantes'),
    path('fabricantes/<int:fabricante_id>/', views.FabricanteDetalhes, name='fabricanteDetalhes'),

    #pescadores
    path('pescadores', views.Pescadores, name='pescadores'),
    path('pescadores/<int:pescador_id>/', views.PescadorDetalhes, name='pescadorDetalhes'),

    #pesca
    path('pescas', views.Pescas, name='pescas'),
    path('pescas/<int:pesca_id>/', views.PescaDetalhes, name='pescaDetalhes'),

    #canadepesca
    path('canasdepesca', views.Canasdepesca, name='canasdepesca'),
    path('canasdepesca/<int:canadepesca_id>/', views.CanadepescaDetalhes, name='canadepescaDetalhes'),

    #imagem
    path('imagens', views.Imagens, name='Imagens'),
]
